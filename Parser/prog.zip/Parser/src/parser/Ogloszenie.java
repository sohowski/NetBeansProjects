
package parser;

import java.time.LocalDate;

public class Ogloszenie {
    long        id;
    String      tytul;
    LocalDate   dataDodania;
    LocalDate   dataKonca;
    float       cena;
    String      idWystawcy;
    int         wyswietlenia;
    String      opis;
    
}
